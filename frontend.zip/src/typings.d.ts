declare var module: NodeModule;
declare var stripe: any;
declare var Marzipano: any;
declare var bowser: any;
declare var screenfull: any;
declare var elements: any;

interface NodeModule {
  id: string;
}
