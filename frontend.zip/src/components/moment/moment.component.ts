import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moment',
  templateUrl: './moment.component.html',
  styleUrls: ['./moment.component.scss']
})
export class MomentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
