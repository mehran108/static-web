import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-core-values',
  templateUrl: './core-values.component.html',
  styleUrls: ['./core-values.component.scss']
})
export class CoreValuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
