export const environment = {
  production: true,
  uploadPath: 'https://api.nabapplicationforms.com/weatherforecast/uploaddoc'
};
